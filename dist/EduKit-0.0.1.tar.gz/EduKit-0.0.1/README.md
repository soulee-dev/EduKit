# EduKit
Lecture of Python.
